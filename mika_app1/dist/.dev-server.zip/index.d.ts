export * from './compiled-types/src/components/ProviderComponent';
export { default } from './compiled-types/src/components/ProviderComponent';