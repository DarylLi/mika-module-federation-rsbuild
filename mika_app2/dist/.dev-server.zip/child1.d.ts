export * from './compiled-types/src/components/child';
export { default } from './compiled-types/src/components/child';