export * from './compiled-types/src/components/child2';
export { default } from './compiled-types/src/components/child2';