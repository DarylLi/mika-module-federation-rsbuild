import React from "react";
import "./ProviderComponent.css";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "swiper/css/scrollbar";
import "./style.css";
declare const Provider: React.FC;
export default Provider;
