import React from 'react';
import './index.css';
declare const Provider: React.FC;
export default Provider;
