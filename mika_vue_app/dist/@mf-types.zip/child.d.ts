export * from './compiled-types/App.vue';
export { default } from './compiled-types/App.vue';