declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: Vue.DefineComponent<{}, {}, {}, {}, {}, Vue.ComponentOptionsMixin, Vue.ComponentOptionsMixin, {}, string, Vue.PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, Vue.ComponentProvideOptions, true, {}, any>;
import * as Vue from "vue";
