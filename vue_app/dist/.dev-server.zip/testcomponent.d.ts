export * from './compiled-types/src/testcmpt.vue';
export { default } from './compiled-types/src/testcmpt.vue';