export * from './compiled-types/src/components/async1.vue';
export { default } from './compiled-types/src/components/async1.vue';