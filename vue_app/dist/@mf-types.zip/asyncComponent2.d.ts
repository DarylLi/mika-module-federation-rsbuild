export * from './compiled-types/src/components/async2.vue';
export { default } from './compiled-types/src/components/async2.vue';