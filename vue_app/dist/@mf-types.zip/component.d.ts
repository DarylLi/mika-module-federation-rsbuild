export * from './compiled-types/src/component.vue';
export { default } from './compiled-types/src/component.vue';